
import React, { useState, useEffect } from 'react';
import { AppTab, User, Ride, DbStatus } from './types';
import Login from './components/Login';
import TripScreen from './components/TripScreen';
import MyRidesScreen from './components/MyRidesScreen';
import MoreScreen from './components/MoreScreen';
import BottomNav from './components/BottomNav';
import { BRAND_NAME } from './constants';
import { dbService } from './services/db';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.TRIP);
  const [rides, setRides] = useState<Ride[]>([]);
  const [dbStatus, setDbStatus] = useState<DbStatus>('Connected');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initApp = async () => {
      setLoading(true);
      const savedUser = await dbService.getUserProfile();
      if (savedUser) {
        setUser(savedUser);
      }
      const savedRides = await dbService.getRides();
      setRides(savedRides);
      setLoading(false);
    };
    initApp();
  }, []);

  const handleLogin = async (userData: User) => {
    setUser(userData);
    await dbService.saveUserProfile(userData);
  };

  const handleUpdateUser = async (userData: User) => {
    setDbStatus('Syncing');
    await dbService.syncUserProfile(userData);
    setUser(userData);
    setDbStatus('Connected');
  };

  const handleLogout = async () => {
    await dbService.clearLocalData();
    setUser(null);
    setRides([]);
    setActiveTab(AppTab.TRIP);
  };

  const addRide = async (newRide: Ride) => {
    if (!user) return;
    setRides(prev => [newRide, ...prev]);
    setActiveTab(AppTab.MY_RIDES);
    setDbStatus('Syncing');
    try {
      const success = await dbService.syncToGoogleSheets(newRide, user);
      if (success) {
        setTimeout(() => setDbStatus('Connected'), 1500);
      } else {
        setDbStatus('Error');
      }
    } catch (e) {
      setDbStatus('Error');
    }
  };

  const cancelRide = async (rideId: string) => {
    if (!user) return;
    const rideToCancel = rides.find(r => r.id === rideId);
    if (!rideToCancel) return;

    setDbStatus('Syncing');
    const cancelledRide = { ...rideToCancel, status: 'Cancelled' as const };
    setRides(prev => prev.map(r => r.id === rideId ? cancelledRide : r));
    
    try {
      await dbService.syncToGoogleSheets(cancelledRide, user);
      setTimeout(() => setDbStatus('Connected'), 1500);
    } catch (e) {
      setDbStatus('Error');
    }
  };

  if (loading && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-4 border-[#46D5B3] border-t-transparent rounded-full animate-spin"></div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Connecting NeoCloud...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-white px-6 py-4 flex justify-between items-center sticky top-0 z-50 shadow-sm border-b border-slate-50">
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="text-[#46D5B3] font-black text-2xl tracking-tighter leading-none">{BRAND_NAME}</span>
            <div className={`w-1.5 h-1.5 rounded-full mt-1 ${
              dbStatus === 'Connected' ? 'bg-green-500' : 
              dbStatus === 'Syncing' ? 'bg-orange-400 animate-pulse' : 'bg-red-500'
            }`}></div>
          </div>
          <span className="text-[8px] text-slate-400 font-black tracking-[0.25em] uppercase mt-0.5">
            TRAVEL SMARTLY
          </span>
        </div>
        
        <div className="flex items-center gap-3">
          {dbStatus === 'Syncing' && (
            <span className="text-[7px] font-black text-[#46D5B3] uppercase tracking-widest animate-pulse">
              Syncing...
            </span>
          )}
          <button 
            onClick={() => setActiveTab(AppTab.MORE)}
            className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all overflow-hidden border ${
              activeTab === AppTab.MORE ? 'border-[#46D5B3] ring-2 ring-[#46D5B3]/10' : 'border-transparent bg-[#46D5B3]/10 text-[#46D5B3]'
            }`}
          >
            {user.avatar ? (
              <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <span className="font-black text-xs">{user.name.charAt(0)}</span>
            )}
          </button>
        </div>
      </header>

      <main className="flex-1 px-4 py-6 pb-40">
        {activeTab === AppTab.TRIP && <TripScreen user={user} onBooking={addRide} />}
        {activeTab === AppTab.MY_RIDES && <MyRidesScreen rides={rides} onCancel={cancelRide} />}
        {activeTab === AppTab.MORE && (
          <MoreScreen 
            user={user} 
            onLogout={handleLogout} 
            onUpdateUser={handleUpdateUser} 
            dbStatus={dbStatus}
            rideCount={rides.length}
          />
        )}
      </main>

      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
};

export default App;
