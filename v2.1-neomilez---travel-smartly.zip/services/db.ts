
import { User, DbStatus, Ride } from '../types';

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
}

class NeoDatabaseService {
  private status: DbStatus = 'Connected';
  private walletKey = 'neomilez_wallet_history';
  private contactsKey = 'neomilez_emergency_contacts';
  private safetySettingsKey = 'neomilez_safety_settings';
  private ridesKey = 'neomilez_rides_ledger';
  private userKey = 'neomilez_user_profile';
  
  private lastDispatchedId: string | null = null;
  private isSyncing = false;
  
  private googleSheetsUrl = 'https://script.google.com/macros/s/AKfycbyRuDzP7ORXazwNndNsgj7WxjjFwELGHOVScrW8iJWhox8e5LIBnDin-E2zYI8s6NgUXA/exec';

  constructor() {
    console.log('NeoDB Engine v5: Persistent Local + Cloud Active');
  }

  // --- USER PROFILE PERSISTENCE ---
  async saveUserProfile(user: User): Promise<void> {
    localStorage.setItem(this.userKey, JSON.stringify(user));
  }

  async getUserProfile(): Promise<User | null> {
    const data = localStorage.getItem(this.userKey);
    return data ? JSON.parse(data) : null;
  }

  async syncUserProfile(user: User): Promise<void> {
    await this.saveUserProfile(user);
    // Cloud sync could be added here if needed
    await new Promise(r => setTimeout(r, 100));
  }

  // --- BOOKING HISTORY PERSISTENCE ---
  async saveRide(ride: Ride): Promise<void> {
    const rides = await this.getRides();
    const updated = [ride, ...rides.filter(r => r.id !== ride.id)];
    localStorage.setItem(this.ridesKey, JSON.stringify(updated));
  }

  async getRides(): Promise<Ride[]> {
    const data = localStorage.getItem(this.ridesKey);
    return data ? JSON.parse(data) : [];
  }

  async clearLocalData(): Promise<void> {
    localStorage.removeItem(this.userKey);
    localStorage.removeItem(this.ridesKey);
    localStorage.removeItem(this.walletKey);
    localStorage.removeItem(this.contactsKey);
  }

  // --- CLOUD SYNC LOGIC ---
  async getStatus(): Promise<DbStatus> {
    return this.status;
  }

  async syncToGoogleSheets(ride: any, user: User): Promise<boolean> {
    // Save locally first (Immediate persistence)
    await this.saveRide(ride);

    if (!this.googleSheetsUrl || this.googleSheetsUrl.includes('YOUR_URL')) {
      console.warn("Sheet Sync: URL not configured.");
      return false;
    }

    if (this.lastDispatchedId === ride.id && ride.status !== 'Cancelled') {
      return true; 
    }

    this.isSyncing = true;
    try {
      const query = new URLSearchParams();
      query.append('ts', new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }));
      query.append('rid', ride.id || 'ERR');
      query.append('name', user.name || 'USER');
      query.append('ph', user.phone || '0000');
      query.append('em', user.email || 'N/A');
      query.append('gen', user.gender || 'N/A');
      query.append('type', ride.type || 'N/A');
      query.append('route', ride.type === 'INTERCITY' ? `${ride.from} to ${ride.to}` : (ride.rentalMode || 'Private'));
      query.append('seats', String(ride.seats || '1'));
      query.append('time', ride.time || 'N/A');
      query.append('car', ride.carName || 'EV');
      query.append('dur', String(ride.duration || 'N/A'));
      query.append('pr', String(ride.price || '0'));
      query.append('st', ride.status || 'Upcoming');
      query.append('m', 'srp_v5_localdb');

      const finalUrl = `${this.googleSheetsUrl}?${query.toString()}`;

      await fetch(finalUrl, { 
        method: 'GET',
        mode: 'no-cors', 
        cache: 'no-cache',
        keepalive: true
      });

      this.lastDispatchedId = ride.id;
      this.isSyncing = false;
      return true;
    } catch (error) {
      console.error('SRP Sync Failure:', error);
      this.isSyncing = false;
      return false;
    }
  }

  // --- OTHER DATA ---
  async getWalletHistory(): Promise<any[]> {
    const data = localStorage.getItem(this.walletKey);
    return data ? JSON.parse(data) : [{ id: '1', amount: 1000, type: 'Credit', desc: 'Welcome Bonus', date: '2023-10-01' }];
  }

  async addWalletTransaction(amount: number, type: 'Credit' | 'Debit', desc: string): Promise<void> {
    const history = await this.getWalletHistory();
    const entry = {
      id: Math.random().toString(36).substr(2, 9),
      amount, type, desc,
      date: new Date().toISOString().split('T')[0]
    };
    localStorage.setItem(this.walletKey, JSON.stringify([entry, ...history]));
  }

  async getEmergencyContacts(): Promise<EmergencyContact[]> {
    const data = localStorage.getItem(this.contactsKey);
    return data ? JSON.parse(data) : [{ id: '1', name: 'Emergency Services', phone: '112' }];
  }

  async addEmergencyContact(contact: Omit<EmergencyContact, 'id'>): Promise<void> {
    const contacts = await this.getEmergencyContacts();
    const newContact = { ...contact, id: Math.random().toString(36).substr(2, 9) };
    localStorage.setItem(this.contactsKey, JSON.stringify([...contacts, newContact]));
  }

  async removeEmergencyContact(id: string): Promise<void> {
    const contacts = await this.getEmergencyContacts();
    const updated = contacts.filter(c => c.id !== id);
    localStorage.setItem(this.contactsKey, JSON.stringify(updated));
  }

  async getSafetySettings(): Promise<{ shareLiveLocation: boolean }> {
    const data = localStorage.getItem(this.safetySettingsKey);
    return data ? JSON.parse(data) : { shareLiveLocation: false };
  }

  async updateSafetySettings(settings: { shareLiveLocation: boolean }): Promise<void> {
    localStorage.setItem(this.safetySettingsKey, JSON.stringify(settings));
  }
}

export const dbService = new NeoDatabaseService();
