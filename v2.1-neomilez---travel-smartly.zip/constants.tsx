
import { Route, RouteCategory } from './types';

export const BRAND_COLOR = '#46D5B3'; // Updated brand teal from logo
export const BRAND_NAME = 'NEOMILEZ';

export const ROUTES: Route[] = [
  { id: '1', from: 'Bangalore', to: 'Mysuru', pricePerSeat: 500, category: RouteCategory.INTERCITY },
  { id: '2', from: 'Mysuru', to: 'Bangalore', pricePerSeat: 500, category: RouteCategory.INTERCITY },
  { id: '3', from: 'Bangalore City', to: 'Airport', pricePerSeat: 400, category: RouteCategory.AIRPORT },
  { id: '4', from: 'Airport', to: 'Bangalore City', pricePerSeat: 400, category: RouteCategory.AIRPORT },
  { id: '5', from: 'Bangalore', to: 'Hosur', pricePerSeat: 350, category: RouteCategory.INTERCITY },
  { id: '6', from: 'Hosur', to: 'Bangalore', pricePerSeat: 350, category: RouteCategory.INTERCITY },
];

export const TIME_SLOTS = [
  '06:00 AM', '08:00 AM', '10:00 AM', '12:00 PM', 
  '02:00 PM', '04:00 PM', '06:00 PM', '08:00 PM', '10:00 PM'
];

export const RENTAL_PACKAGES = [4, 8, 12, 24];
export const HOURLY_RATE = 300;
