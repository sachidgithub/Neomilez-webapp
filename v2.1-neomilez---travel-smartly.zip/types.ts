
export enum AppTab {
  TRIP = 'TRIP',
  MY_RIDES = 'MY_RIDES',
  MORE = 'MORE'
}

export enum BookingType {
  INTERCITY = 'INTERCITY',
  PRIVATE_RENTAL = 'PRIVATE_RENTAL'
}

export enum RouteCategory {
  INTERCITY = 'INTERCITY',
  AIRPORT = 'AIRPORT'
}

export type DbStatus = 'Connected' | 'Syncing' | 'Offline' | 'Error';

export interface User {
  name: string;
  phone: string;
  email?: string;
  gender?: 'Male' | 'Female' | 'Other';
  db_id?: string;
  balance?: number;
  avatar?: string; // Base64 encoded string
}

export interface Route {
  id: string;
  from: string;
  to: string;
  pricePerSeat: number;
  category: RouteCategory;
}

export interface Ride {
  id: string;
  type: BookingType;
  from: string;
  to: string;
  date: string;
  time: string;
  status: 'Upcoming' | 'Completed' | 'Cancelled';
  price: number;
  seats?: number;
  duration?: number;
  created_at?: string;
  carName?: string;
}
