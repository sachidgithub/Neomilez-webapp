
import React, { useState } from 'react';
import { Ride, BookingType } from '../types';

interface MyRidesScreenProps {
  rides: Ride[];
  onCancel: (id: string) => void;
}

const MyRidesScreen: React.FC<MyRidesScreenProps> = ({ rides, onCancel }) => {
  const [activeSegment, setActiveSegment] = useState<'Upcoming' | 'History'>('Upcoming');
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [supportId, setSupportId] = useState<string | null>(null);

  const upcomingRides = rides.filter(r => r.status === 'Upcoming');
  const historyRides = rides.filter(r => r.status === 'Completed' || r.status === 'Cancelled');

  const displayedRides = activeSegment === 'Upcoming' ? upcomingRides : historyRides;

  const handleCancelClick = (id: string) => {
    setCancellingId(id);
  };

  const confirmCancellation = () => {
    if (cancellingId) {
      onCancel(cancellingId);
      setCancellingId(null);
    }
  };

  const SupportOverlay = ({ rideId }: { rideId: string }) => (
    <div className="fixed inset-0 z-[200] flex flex-col justify-end bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white rounded-t-[3rem] p-8 pb-12 animate-in slide-in-from-bottom duration-300 shadow-2xl">
        <div className="w-12 h-1.5 bg-slate-100 rounded-full mx-auto mb-8"></div>
        <h4 className="text-xl font-black text-slate-800 mb-1">Ride Support</h4>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-8">Ref: NEO-{rideId}</p>
        
        <div className="space-y-3">
          <a href="tel:+919876543210" className="flex items-center gap-4 p-5 bg-slate-50 rounded-2xl border border-slate-100 active:scale-[0.98] transition-all">
            <div className="w-10 h-10 bg-green-500 text-white rounded-xl flex items-center justify-center">
              <i className="fa-solid fa-phone"></i>
            </div>
            <div className="flex-1">
              <p className="text-sm font-black text-slate-800">Call Support Team</p>
              <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Direct link to active dispatcher</p>
            </div>
          </a>
          <a href={`https://wa.me/919876543210?text=Hi, I need help with my booking NEO-${rideId}`} target="_blank" className="flex items-center gap-4 p-5 bg-slate-50 rounded-2xl border border-slate-100 active:scale-[0.98] transition-all">
            <div className="w-10 h-10 bg-[#25D366] text-white rounded-xl flex items-center justify-center text-xl">
              <i className="fa-brands fa-whatsapp"></i>
            </div>
            <div className="flex-1">
              <p className="text-sm font-black text-slate-800">Chat on WhatsApp</p>
              <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Instant text-based resolution</p>
            </div>
          </a>
          <a href={`mailto:support@neomilez.com?subject=Support Request: NEO-${rideId}`} className="flex items-center gap-4 p-5 bg-slate-50 rounded-2xl border border-slate-100 active:scale-[0.98] transition-all">
            <div className="w-10 h-10 bg-[#46D5B3] text-white rounded-xl flex items-center justify-center">
              <i className="fa-solid fa-envelope"></i>
            </div>
            <div className="flex-1">
              <p className="text-sm font-black text-slate-800">Email Query</p>
              <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Expected reply within 4 hours</p>
            </div>
          </a>
        </div>
        
        <button 
          onClick={() => setSupportId(null)}
          className="w-full mt-8 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] tracking-widest uppercase shadow-xl"
        >
          Back to Rides
        </button>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {supportId && <SupportOverlay rideId={supportId} />}
      
      <div className="flex flex-col gap-6">
        <h2 className="text-3xl font-black text-slate-800 tracking-tight">My Rides</h2>
        
        <div className="bg-slate-200 p-1 rounded-2xl flex relative">
          <button 
            onClick={() => setActiveSegment('Upcoming')}
            className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all z-10 ${
              activeSegment === 'Upcoming' ? 'text-slate-800' : 'text-slate-400'
            }`}
          >
            Upcoming
            {upcomingRides.length > 0 && (
              <span className="ml-2 bg-[#46D5B3] text-white text-[8px] px-1.5 py-0.5 rounded-full">
                {upcomingRides.length}
              </span>
            )}
          </button>
          <button 
            onClick={() => setActiveSegment('History')}
            className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all z-10 ${
              activeSegment === 'History' ? 'text-slate-800' : 'text-slate-400'
            }`}
          >
            History
          </button>
          <div 
            className={`absolute top-1 bottom-1 w-[calc(50%-4px)] bg-white rounded-xl shadow-sm transition-transform duration-300 ease-out ${
              activeSegment === 'History' ? 'translate-x-[calc(100%+0px)]' : 'translate-x-0'
            }`}
          />
        </div>
      </div>

      {displayedRides.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6 text-slate-200 border-2 border-dashed border-slate-200">
            <i className={`fa-solid ${activeSegment === 'Upcoming' ? 'fa-calendar-day' : 'fa-clock-rotate-left'} text-3xl`}></i>
          </div>
          <h3 className="text-lg font-bold text-slate-800">
            {activeSegment === 'Upcoming' ? 'No upcoming journeys' : 'No past trips found'}
          </h3>
          <p className="text-slate-400 text-xs mt-2 max-w-[200px] font-medium leading-relaxed uppercase tracking-wider">
            {activeSegment === 'Upcoming' ? 'Ready for a new trip? Book now in the Trip tab.' : 'Your travel history will appear here.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {displayedRides.map(ride => (
            <div key={ride.id} className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 relative overflow-hidden">
              <div className="flex justify-between items-start mb-5">
                <div className="flex flex-col gap-1">
                  <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-lg tracking-wider w-fit ${
                    ride.type === BookingType.INTERCITY ? 'bg-blue-50 text-blue-500' : 'bg-purple-50 text-purple-500'
                  }`}>
                    {ride.type === BookingType.INTERCITY ? 'Shared Ride' : 'Private Rental'}
                  </span>
                  <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">ID: NEO-{ride.id}</p>
                </div>
                <span className={`text-[9px] font-black uppercase px-2.5 py-1 rounded-lg tracking-wider ${
                  ride.status === 'Upcoming' ? 'bg-[#46D5B3]/10 text-[#46D5B3]' : 
                  ride.status === 'Cancelled' ? 'bg-red-50 text-red-400' : 'bg-slate-100 text-slate-500'
                }`}>
                  {ride.status}
                </span>
              </div>
              
              <div className="flex items-start gap-4 mb-6">
                <div className="flex flex-col items-center pt-1.5">
                  <div className={`w-2 h-2 rounded-full border-2 ${ride.status === 'Cancelled' ? 'border-red-200' : 'border-[#46D5B3]'} bg-white`}></div>
                  <div className="w-[1.5px] h-10 bg-slate-50"></div>
                  <div className={`w-2 h-2 rounded-full ${ride.status === 'Cancelled' ? 'bg-red-200' : 'bg-[#46D5B3]'}`}></div>
                </div>
                <div className="flex-1 space-y-7">
                  <p className={`font-bold text-sm leading-none ${ride.status === 'Cancelled' ? 'text-slate-400' : 'text-slate-800'}`}>{ride.from}</p>
                  <p className={`font-bold text-sm leading-none ${ride.status === 'Cancelled' ? 'text-slate-400' : 'text-slate-800'}`}>{ride.to}</p>
                </div>
              </div>

              {ride.status === 'Upcoming' && (
                <div className="bg-slate-50/50 rounded-2xl p-4 grid grid-cols-3 gap-2 mb-5 border border-slate-50">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-[#46D5B3] shadow-sm flex-shrink-0">
                      <i className="fa-solid fa-users text-[10px]"></i>
                    </div>
                    <div className="overflow-hidden">
                      <p className="text-[7px] font-black text-slate-400 uppercase tracking-widest truncate">Seats</p>
                      <p className="text-[10px] font-black text-slate-800 truncate">{ride.seats || (ride.type === BookingType.PRIVATE_RENTAL ? 'Full EV' : '1')}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 border-x border-slate-100 px-2">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-blue-400 shadow-sm flex-shrink-0">
                      <i className="fa-solid fa-car-side text-[10px]"></i>
                    </div>
                    <div className="overflow-hidden">
                      <p className="text-[7px] font-black text-slate-400 uppercase tracking-widest truncate">Vehicle</p>
                      <p className="text-[10px] font-black text-slate-800 truncate">{ride.carName || 'EV'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pl-1">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-orange-400 shadow-sm flex-shrink-0">
                      <i className="fa-solid fa-bolt text-[10px]"></i>
                    </div>
                    <div className="overflow-hidden">
                      <p className="text-[7px] font-black text-slate-400 uppercase tracking-widest truncate">Time</p>
                      <p className="text-[10px] font-black text-slate-800 truncate">{ride.duration ? `${ride.duration}h` : 'Est. 3h'}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-5 border-t border-slate-50 flex justify-between items-end">
                <div className="space-y-1">
                  <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Departure</p>
                  <div className="flex gap-2 text-slate-500 font-black text-[10px] uppercase tracking-tighter">
                    <span>{ride.date}</span>
                    <span>•</span>
                    <span>{ride.time}</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1">Total Paid</p>
                  <p className={`font-black text-lg ${ride.status === 'Cancelled' ? 'text-slate-400 line-through' : 'text-slate-900'}`}>₹{ride.price}</p>
                </div>
              </div>
              
              {ride.status === 'Upcoming' && (
                <div className="grid grid-cols-2 gap-3 mt-6">
                   <button 
                    onClick={() => setSupportId(ride.id)}
                    className="py-3 bg-slate-50 text-slate-500 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-100 transition-colors"
                   >
                     Support
                   </button>
                   <button 
                    onClick={() => handleCancelClick(ride.id)}
                    className="py-3 bg-red-50/50 text-red-500 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-50 transition-colors"
                   >
                     Cancel
                   </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {cancellingId && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-xs rounded-[2.5rem] p-8 shadow-2xl animate-in zoom-in-95 duration-200">
             <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center text-2xl mx-auto mb-6">
                <i className="fa-solid fa-circle-exclamation"></i>
             </div>
             <h4 className="text-xl font-black text-slate-800 text-center mb-2 tracking-tight">Stop this journey?</h4>
             <p className="text-slate-400 text-center text-[10px] font-black uppercase tracking-widest mb-8 leading-relaxed">
               Trip cancellation might incur a small processing fee.
             </p>
             <div className="space-y-3">
                <button 
                  onClick={confirmCancellation}
                  className="w-full py-4 bg-red-500 text-white rounded-2xl font-black text-xs tracking-[0.2em] active:scale-[0.98] transition-all"
                >
                  YES, CANCEL RIDE
                </button>
                <button 
                  onClick={() => setCancellingId(null)}
                  className="w-full py-4 bg-slate-50 text-slate-500 rounded-2xl font-black text-xs tracking-[0.2em] active:scale-[0.98] transition-all"
                >
                  KEEP TRIP
                </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MyRidesScreen;
