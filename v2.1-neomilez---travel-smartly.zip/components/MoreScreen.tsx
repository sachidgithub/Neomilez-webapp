
import React, { useState, useEffect, useRef } from 'react';
import { User, DbStatus, BookingType } from '../types';
import { BRAND_NAME, BRAND_COLOR } from '../constants';
import { dbService, EmergencyContact } from '../services/db';

interface MoreScreenProps {
  user: User;
  onLogout: () => void;
  onUpdateUser: (user: User) => void;
  dbStatus?: DbStatus;
  rideCount?: number;
}

type MoreView = 'MENU' | 'PROFILE' | 'WALLET' | 'OFFERS' | 'HELP' | 'SAFETY' | 'ABOUT' | 'LEGAL';

interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

const menuItems: { id: MoreView; label: string; icon: string; color: string }[] = [
  { id: 'PROFILE', label: 'Edit Profile', icon: 'fa-solid fa-user-pen', color: 'text-blue-500' },
  { id: 'WALLET', label: 'Neo Wallet', icon: 'fa-solid fa-wallet', color: 'text-green-500' },
  { id: 'OFFERS', label: 'Coupons & Offers', icon: 'fa-solid fa-percent', color: 'text-orange-500' },
  { id: 'SAFETY', label: 'Safety Vault', icon: 'fa-solid fa-shield-halved', color: 'text-red-500' },
  { id: 'HELP', label: 'Support Hub', icon: 'fa-solid fa-headset', color: 'text-[#46D5B3]' },
  { id: 'ABOUT', label: 'About Neomilez', icon: 'fa-solid fa-circle-info', color: 'text-slate-500' },
];

const LEGAL_CONTENT: Record<string, { title: string, content: string[] }> = {
  'Terms of Service': {
    title: 'Terms of Service',
    content: [
      'By using Neomilez, you agree to comply with our shared mobility guidelines.',
      'Riders must be at the boarding point at least 10 minutes before the scheduled departure.',
      'Neomilez reserves the right to cancel or reschedule rides due to unforeseen technical or weather conditions.',
      'Users are responsible for any damage caused to the vehicle during private rentals.',
      'Zero tolerance policy for smoking or substance use inside any Neomilez EV.'
    ]
  },
  'Privacy Policy': {
    title: 'Privacy Policy',
    content: [
      'We collect your location data to provide real-time tracking and safety features.',
      'Your personal information is encrypted and never sold to third-party advertisers.',
      'Payment information is handled by PCI-DSS compliant partners.',
      'We use cookies to improve your booking experience and remember your preferences.'
    ]
  },
  'Cookie Policy': {
    title: 'Cookie Policy',
    content: [
      'Essential cookies: Required for login and booking security.',
      'Performance cookies: Help us understand how riders interact with the app.',
      'Functional cookies: Remember your preferred routes and vehicle choices.',
      'You can manage cookie preferences through your device browser settings.'
    ]
  },
  'Refund Policy': {
    title: 'Refund Policy',
    content: [
      'Full refund for cancellations made 4+ hours before departure.',
      '50% refund for cancellations between 2 to 4 hours before departure.',
      'No refund for cancellations made less than 2 hours before departure.',
      'Refunds are processed to the original payment source within 5-7 business days.'
    ]
  }
};

const FAQ_DATA: Record<string, FAQItem[]> = {
  'General': [
    { id: 'g1', question: `What is ${BRAND_NAME}?`, answer: `${BRAND_NAME} is India's premier EV-only intercity platform. We offer scheduled shared trips and private premium rentals using a state-of-the-art electric fleet, ensuring a carbon-neutral and luxurious travel experience.` },
    { id: 'g2', question: 'How do boarding points work?', answer: 'For shared intercity rides, we have designated "Neo Hubs" in central city locations. You will receive the exact Google Maps location of your boarding point 2 hours before departure.' },
    { id: 'g3', question: 'Is luggage allowed?', answer: 'In shared rides, each passenger is allowed one standard suitcase (up to 20kg) and one handbag. For heavy luggage, we recommend booking a Private Rental.' }
  ],
  'Booking & Policies': [
    { id: 'b1', question: 'How do I book a shared intercity ride?', answer: 'Navigate to the "Trip" tab, select "Fixed Routes", choose your destination, vehicle preference, and time slot. Confirm the booking to secure your seat.' },
    { id: 'b2', question: 'Can I book for multiple people?', answer: 'Yes, you can select up to 3 seats per booking for shared intercity rides. For larger groups, we recommend the Private Rental option.' },
    { id: 'b3', question: 'What is the cancellation policy?', answer: 'Cancellations made 4+ hours before departure are free. Cancellations within 2-4 hours incur a 50% fee. No refunds for cancellations under 2 hours.' },
    { id: 'b4', question: 'What if I miss my ride?', answer: 'Our EVs follow a strict schedule to respect all passengers time. We wait for a maximum of 10 minutes at the hub. Missed rides are treated as no-shows and are non-refundable.' }
  ],
  'EV & Technology': [
    { id: 's1', question: 'What happens if the EV runs out of charge?', answer: 'Our fleet is monitored in real-time. We only assign vehicles with sufficient range for your journey. In the rare case of a depletion, a backup EV is dispatched immediately.' },
    { id: 's2', question: 'Are the vehicles sanitized?', answer: 'Yes, every Neomilez EV undergoes a "Deep Clean" protocol after every intercity trip, focusing on high-touch surfaces like door handles, armrests, and AC vents.' },
    { id: 's3', question: 'Can I charge my phone in the EV?', answer: 'Absolutely. Every seat in our premium fleet (Ioniq 5, EV6) is equipped with dedicated USB-C fast charging ports.' }
  ],
  'Payments & Wallet': [
    { id: 'p1', question: 'Is the pricing inclusive of tolls?', answer: 'For Shared Rides, tolls and taxes are fully inclusive. For Private Rentals, tolls and parking are charged at actuals unless you opt for an "All-Inclusive" package.' },
    { id: 'p2', question: 'How do I use my wallet balance?', answer: 'Wallet balance is the primary payment method. If your balance is sufficient, it is automatically applied to your booking. You can top up via UPI or Cards anytime.' }
  ]
};

const OFFERS_DATA = [
  { id: 'OFFER1', code: 'NEOFAST', discount: '₹100 OFF', desc: 'On your first intercity ride', color: 'bg-green-500' },
  { id: 'OFFER2', code: 'ECOAIR', discount: '15% OFF', desc: 'Airport transfers this weekend', color: 'bg-blue-500' },
  { id: 'OFFER3', code: 'LUXE50', discount: '₹500 OFF', desc: 'Private rental for 12h+ packages', color: 'bg-purple-500' },
];

const MoreScreen: React.FC<MoreScreenProps> = ({ user, onLogout, onUpdateUser, dbStatus = 'Offline', rideCount = 0 }) => {
  const [activeView, setActiveView] = useState<MoreView>('MENU');
  const [selectedLegal, setSelectedLegal] = useState<string | null>(null);
  const [editName, setEditName] = useState(user.name);
  const [editEmail, setEditEmail] = useState(user.email || '');
  const [editAvatar, setEditAvatar] = useState(user.avatar || '');
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // SOS & Safety States
  const [showSosConfirm, setShowSosConfirm] = useState(false);
  const [sosCountdown, setSosCountdown] = useState<number | null>(null);
  const [isSosActive, setIsSosActive] = useState(false);
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [shareLive, setShareLive] = useState(false);
  const [newContactName, setNewContactName] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [isAddingContact, setIsAddingContact] = useState(false);
  const [currentCoords, setCurrentCoords] = useState<{lat: number, lng: number} | null>(null);
  const watchIdRef = useRef<number | null>(null);

  const [walletHistory, setWalletHistory] = useState<any[]>([]);
  const [isToppingUp, setIsToppingUp] = useState(false);
  const [isTestSyncing, setIsTestSyncing] = useState(false);

  // New state for Logout confirmation
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  useEffect(() => {
    if (activeView === 'WALLET') {
      dbService.getWalletHistory().then(setWalletHistory);
    }
    if (activeView === 'SAFETY') {
      dbService.getEmergencyContacts().then(setContacts);
      dbService.getSafetySettings().then(s => setShareLive(s.shareLiveLocation));
    }
    if (activeView === 'PROFILE') {
      setEditName(user.name);
      setEditEmail(user.email || '');
      setEditAvatar(user.avatar || '');
    }
  }, [activeView, user]);

  useEffect(() => {
    if (shareLive && activeView === 'SAFETY') {
      if ('geolocation' in navigator) {
        watchIdRef.current = navigator.geolocation.watchPosition(
          (position) => {
            setCurrentCoords({
              lat: position.coords.latitude,
              lng: position.coords.longitude
            });
          },
          (error) => {
            console.error("Geolocation Error:", error);
          },
          { enableHighAccuracy: true }
        );
      }
    } else {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      setCurrentCoords(null);
    }

    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, [shareLive, activeView]);

  useEffect(() => {
    let timer: any;
    if (sosCountdown !== null && sosCountdown > 0) {
      timer = setTimeout(() => setSosCountdown(sosCountdown - 1), 1000);
    } else if (sosCountdown === 0) {
      triggerSosAlert();
    }
    return () => clearTimeout(timer);
  }, [sosCountdown]);

  const startSosCountdown = () => {
    setSosCountdown(5);
    setShowSosConfirm(false);
  };

  const cancelSos = () => {
    setSosCountdown(null);
    setIsSosActive(false);
  };

  const triggerSosAlert = () => {
    setSosCountdown(null);
    setIsSosActive(true);
    console.log("SOS Alert Transmitted to Safety Command Center and Authorities.");
  };

  const handleAddContact = async () => {
    if (newContactName && newContactPhone.length === 10) {
      await dbService.addEmergencyContact({ name: newContactName, phone: newContactPhone });
      const updated = await dbService.getEmergencyContacts();
      setContacts(updated);
      setNewContactName('');
      setNewContactPhone('');
      setIsAddingContact(false);
    }
  };

  const handleRemoveContact = async (id: string) => {
    await dbService.removeEmergencyContact(id);
    const updated = await dbService.getEmergencyContacts();
    setContacts(updated);
  };

  const toggleShareLive = async () => {
    const newVal = !shareLive;
    setShareLive(newVal);
    await dbService.updateSafetySettings({ shareLiveLocation: newVal });
  };

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({ ...user, name: editName, email: editEmail, avatar: editAvatar });
    setActiveView('MENU');
  };

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Image size should be less than 2MB");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTopUp = async () => {
    setIsToppingUp(true);
    await new Promise(r => setTimeout(r, 1500));
    const addAmount = 500;
    const newBalance = (user.balance || 0) + addAmount;
    await dbService.addWalletTransaction(addAmount, 'Credit', 'Wallet Top-up');
    onUpdateUser({ ...user, balance: newBalance });
    const history = await dbService.getWalletHistory();
    setWalletHistory(history);
    setIsToppingUp(false);
  };

  const handleForceSyncTest = async () => {
    setIsTestSyncing(true);
    const testRide = {
      id: "TEST-" + Math.random().toString(36).substr(2, 5).toUpperCase(),
      type: BookingType.INTERCITY,
      from: "BANGALORE",
      to: "MYSURU",
      seats: 1,
      time: "TEST_TIME",
      carName: "TEST_VEHICLE",
      price: 999,
      status: "Upcoming"
    };
    
    // Calls the sync logic manually
    // @ts-ignore - reaching into private for testing
    await dbService.syncToGoogleSheets(testRide, user);
    
    setTimeout(() => {
      setIsTestSyncing(false);
      alert("Test data pushed! Please check your Google Sheet.");
    }, 1000);
  };

  const BackButton = ({ to = 'MENU' as MoreView }: { to?: MoreView }) => (
    <button 
      onClick={() => setActiveView(to)}
      className="flex items-center gap-2 text-slate-400 font-black text-[10px] uppercase tracking-widest mb-6 hover:text-slate-600 transition-colors"
    >
      <i className="fa-solid fa-chevron-left text-[#46D5B3]"></i> Back to {to === 'MENU' ? 'Menu' : 'About'}
    </button>
  );

  const SubHeader = ({ title, icon, color }: { title: string, icon: string, color: string }) => (
    <div className="flex items-center justify-between mb-8">
      <h2 className="text-3xl font-black text-slate-800 tracking-tight">{title}</h2>
      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl bg-slate-50 ${color}`}>
        <i className={icon}></i>
      </div>
    </div>
  );

  if (showLogoutConfirm) {
    return (
      <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-slate-900/90 backdrop-blur-xl animate-in fade-in duration-300">
        <div className="bg-white w-full max-w-sm rounded-[3rem] p-10 shadow-2xl text-center">
          <div className="w-20 h-20 bg-slate-50 text-slate-800 rounded-full flex items-center justify-center text-3xl mx-auto mb-6">
            <i className="fa-solid fa-right-from-bracket translate-x-1"></i>
          </div>
          <h3 className="text-2xl font-black text-slate-900 mb-2">Wait! Sign out?</h3>
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-10 leading-relaxed">
            You will need to sign in again to book your next eco-friendly journey.
          </p>
          
          <div className="space-y-4">
            <button 
              onClick={onLogout}
              className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black text-xs tracking-[0.3em] uppercase shadow-2xl active:scale-95 transition-all"
            >
              YES, SIGN OUT
            </button>
            <button 
              onClick={() => setShowLogoutConfirm(false)}
              className="w-full py-6 bg-slate-50 text-slate-400 rounded-[2rem] font-black text-xs tracking-[0.3em] uppercase transition-all"
            >
              STAY LOGGED IN
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (showSosConfirm) {
    return (
      <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-slate-900/90 backdrop-blur-xl animate-in fade-in duration-300">
        <div className="bg-white w-full max-w-sm rounded-[3rem] p-10 shadow-2xl text-center">
          <div className="w-20 h-20 bg-red-50 text-red-500 rounded-full flex items-center justify-center text-3xl mx-auto mb-6">
            <i className="fa-solid fa-phone-volume"></i>
          </div>
          <h3 className="text-2xl font-black text-slate-900 mb-2">Confirm Emergency?</h3>
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-10 leading-relaxed">
            This will share your location and details with our Safety Command Center.
          </p>
          
          <div className="space-y-4">
            <button 
              onClick={startSosCountdown}
              className="w-full py-6 bg-red-500 text-white rounded-[2rem] font-black text-xs tracking-[0.3em] uppercase shadow-2xl active:scale-95 transition-all"
            >
              YES, ALERT COMMAND CENTER
            </button>
            <button 
              onClick={() => setShowSosConfirm(false)}
              className="w-full py-6 bg-slate-50 text-slate-400 rounded-[2rem] font-black text-xs tracking-[0.3em] uppercase transition-all"
            >
              CANCEL
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (sosCountdown !== null || isSosActive) {
    return (
      <div className="fixed inset-0 z-[250] flex flex-col items-center justify-center p-8 bg-red-600 animate-in fade-in duration-300">
        <div className="w-full max-w-sm flex flex-col items-center">
          <div className="w-32 h-32 bg-white/20 rounded-full flex items-center justify-center mb-12 animate-pulse">
            <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center text-5xl text-red-600 font-black">
              {isSosActive ? <i className="fa-solid fa-satellite-dish"></i> : sosCountdown}
            </div>
          </div>
          
          <h2 className="text-4xl font-black text-white text-center mb-4 uppercase tracking-tighter">
            {isSosActive ? "SOS ACTIVE" : "SOS ALERT"}
          </h2>
          <p className="text-white/80 text-center text-sm font-bold uppercase tracking-[0.2em] mb-12">
            {isSosActive 
              ? "Safety team and local authorities have been notified of your location." 
              : "Hold to cancel. Alerting authorities in several seconds."}
          </p>

          <div className="w-full space-y-4">
            {isSosActive ? (
              <a href="tel:112" className="w-full py-6 bg-white text-red-600 rounded-[2rem] font-black text-center text-xs tracking-[0.3em] uppercase block shadow-2xl">
                CALL 112 NOW
              </a>
            ) : null}
            <button 
              onClick={cancelSos}
              className="w-full py-6 bg-black/20 text-white border border-white/30 rounded-[2rem] font-black text-xs tracking-[0.3em] uppercase active:scale-95 transition-all"
            >
              {isSosActive ? "DEACTIVATE SOS" : "CANCEL SOS"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (activeView === 'MENU') {
    return (
      <div className="space-y-8 animate-in fade-in duration-500">
        <div className="flex items-center gap-6 p-2">
          <div className="w-20 h-20 rounded-[2rem] bg-slate-900 flex items-center justify-center overflow-hidden text-3xl text-white shadow-xl shadow-slate-200">
            {user.avatar ? (
              <img src={user.avatar} className="w-full h-full object-cover" alt="Profile" />
            ) : (
              user.name.charAt(0)
            )}
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-black text-slate-800 tracking-tight">{user.name}</h2>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">{user.phone}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3">
          {menuItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className="flex items-center justify-between p-6 bg-white rounded-[1.5rem] border border-slate-50 shadow-sm active:scale-[0.98] transition-all group"
            >
              <div className="flex items-center gap-5">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg bg-slate-50 ${item.color}`}>
                  <i className={item.icon}></i>
                </div>
                <span className="font-bold text-slate-700 text-sm">{item.label}</span>
              </div>
              <i className="fa-solid fa-chevron-right text-slate-200 group-hover:text-slate-400 transition-colors text-xs"></i>
            </button>
          ))}
        </div>

        <button 
          onClick={() => setShowLogoutConfirm(true)}
          className="w-full py-5 bg-red-50 text-red-500 rounded-[1.5rem] font-black text-xs tracking-widest uppercase flex items-center justify-center gap-3 active:scale-95 transition-all mt-4"
        >
          <i className="fa-solid fa-power-off"></i> Sign Out
        </button>

        <p className="text-center text-[8px] font-black text-slate-300 uppercase tracking-[0.4em] py-8">
          Neomilez v1.2.5 Beta
        </p>
      </div>
    );
  }

  if (activeView === 'WALLET') {
    return (
      <div className="animate-in slide-in-from-right duration-300 pb-20">
        <BackButton />
        <SubHeader title="Neo Wallet" icon="fa-solid fa-wallet" color="text-green-500" />
        
        <div className="bg-slate-900 p-10 rounded-[4rem] text-white relative overflow-hidden shadow-2xl mb-10">
          <div className="relative z-10 space-y-6">
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mb-2">Available Balance</p>
              <h3 className="text-6xl font-black tracking-tighter">₹{user.balance || 0}</h3>
            </div>
            <button 
              onClick={handleTopUp}
              disabled={isToppingUp}
              className="w-full py-5 bg-[#46D5B3] text-slate-900 rounded-[2rem] font-black text-xs tracking-widest uppercase shadow-xl active:scale-95 transition-all flex items-center justify-center gap-3"
            >
              {isToppingUp ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin"></i> Processing...
                </>
              ) : (
                <>
                  <i className="fa-solid fa-plus"></i> Top Up Wallet
                </>
              )}
            </button>
          </div>
          <i className="fa-solid fa-coins absolute -right-12 -bottom-12 text-white/5 text-[18rem] transform rotate-12"></i>
        </div>

        <div className="space-y-6">
          <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest ml-2">Transaction History</h3>
          <div className="space-y-3">
            {walletHistory.map(tx => (
              <div key={tx.id} className="bg-white p-6 rounded-[2rem] border border-slate-50 flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-lg ${tx.type === 'Credit' ? 'bg-green-50 text-green-500' : 'bg-red-50 text-red-500'}`}>
                    <i className={`fa-solid ${tx.type === 'Credit' ? 'fa-arrow-down' : 'fa-arrow-up'}`}></i>
                  </div>
                  <div>
                    <p className="text-sm font-black text-slate-800">{tx.desc}</p>
                    <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">{tx.date}</p>
                  </div>
                </div>
                <p className={`font-black text-base ${tx.type === 'Credit' ? 'text-green-500' : 'text-red-500'}`}>
                  {tx.type === 'Credit' ? '+' : '-'}₹{tx.amount}
                </p>
              </div>
            ))}
            {walletHistory.length === 0 && (
              <div className="text-center py-10">
                <p className="text-xs font-bold text-slate-300 uppercase tracking-widest">No transactions yet</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (activeView === 'OFFERS') {
    return (
      <div className="animate-in slide-in-from-right duration-300 pb-20">
        <BackButton />
        <SubHeader title="Coupons" icon="fa-solid fa-percent" color="text-orange-500" />
        
        <div className="space-y-6">
          {OFFERS_DATA.map(offer => (
            <div key={offer.id} className="bg-white rounded-[3rem] overflow-hidden border border-slate-100 shadow-sm relative">
              <div className={`${offer.color} h-2`} />
              <div className="p-8 flex justify-between items-center">
                <div className="space-y-1 flex-1">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{offer.desc}</p>
                  <h4 className="text-2xl font-black text-slate-900 tracking-tight">{offer.discount}</h4>
                  <div className="pt-4">
                    <span className="bg-slate-50 px-5 py-2 rounded-xl border-2 border-dashed border-slate-200 text-sm font-black text-slate-600 tracking-widest">
                      {offer.code}
                    </span>
                  </div>
                </div>
                <button 
                  onClick={() => alert(`Applied ${offer.code}!`)}
                  className="w-14 h-14 bg-slate-900 text-white rounded-2xl flex items-center justify-center text-lg active:scale-95 transition-all shadow-xl shadow-slate-200"
                >
                  <i className="fa-solid fa-check"></i>
                </button>
              </div>
              <div className="absolute top-1/2 -left-3 w-6 h-6 bg-slate-50 rounded-full border border-slate-100" />
              <div className="absolute top-1/2 -right-3 w-6 h-6 bg-slate-50 rounded-full border border-slate-100" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (activeView === 'ABOUT') {
    return (
      <div className="animate-in slide-in-from-right duration-300 pb-20">
        <BackButton />
        <SubHeader title="About Us" icon="fa-solid fa-circle-info" color="text-slate-500" />
        
        <div className="flex flex-col items-center text-center space-y-10">
          <div className="space-y-4">
            <h3 className="text-5xl font-black text-slate-900 tracking-tighter">{BRAND_NAME}</h3>
            <p className="text-[10px] font-black text-[#46D5B3] uppercase tracking-[0.5em]">The Future of Travel</p>
          </div>

          <div className="bg-white p-10 rounded-[3.5rem] border border-slate-50 shadow-sm leading-relaxed text-slate-500 font-medium text-sm space-y-6">
            <p>
              Neomilez is India's leading EV-exclusive intercity shared mobility platform. Our mission is to democratize premium, green travel while reducing the carbon footprint of every journey.
            </p>
            <p>
              By leveraging a fleet of high-range electric vehicles and a smart scheduling system, we offer a luxurious yet affordable alternative to traditional travel.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 w-full">
            <div className="bg-white p-6 rounded-3xl border border-slate-50 text-center">
              <p className="text-2xl font-black text-slate-900">50K+</p>
              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Happy Riders</p>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-slate-50 text-center">
              <p className="text-2xl font-black text-slate-900">1.2M</p>
              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">KG CO2 Saved</p>
            </div>
          </div>

          <div className="space-y-4 w-full">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-left ml-2">Legal & Privacy</h4>
            <div className="space-y-2">
              {Object.keys(LEGAL_CONTENT).map(item => (
                <button 
                  key={item} 
                  onClick={() => { setSelectedLegal(item); setActiveView('LEGAL'); }}
                  className="w-full p-5 bg-white rounded-2xl border border-slate-50 text-left text-xs font-bold text-slate-700 flex justify-between items-center group active:scale-[0.98] transition-all"
                >
                  {item}
                  <i className="fa-solid fa-chevron-right text-slate-200 group-hover:text-slate-400 transition-colors"></i>
                </button>
              ))}
            </div>
          </div>

          <div className="w-full bg-slate-900 rounded-[2.5rem] p-8 text-white text-left relative overflow-hidden">
             <div className="relative z-10">
               <p className="text-[9px] font-black text-[#46D5B3] uppercase tracking-[0.3em] mb-2">Our Vision</p>
               <h4 className="text-xl font-black mb-4">Zero Emissions, Zero Compromise.</h4>
               <p className="text-[10px] text-slate-400 font-medium leading-relaxed uppercase tracking-wider">
                 Empowering the next billion travelers with sustainable, tech-driven mobility solutions that respect both time and the planet.
               </p>
             </div>
             <i className="fa-solid fa-leaf absolute -right-4 -bottom-4 text-white/5 text-[8rem]"></i>
          </div>
        </div>
      </div>
    );
  }

  if (activeView === 'LEGAL' && selectedLegal) {
    const doc = LEGAL_CONTENT[selectedLegal];
    return (
      <div className="animate-in slide-in-from-right duration-300 pb-20">
        <BackButton to="ABOUT" />
        <SubHeader title={doc.title} icon="fa-solid fa-file-contract" color="text-slate-500" />
        
        <div className="bg-white p-8 rounded-[3rem] border border-slate-50 shadow-sm space-y-6">
          {doc.content.map((point, i) => (
            <div key={i} className="flex gap-4">
              <div className="w-6 h-6 rounded-full bg-slate-50 flex items-center justify-center text-[10px] font-black text-[#46D5B3] flex-shrink-0 mt-0.5">
                {i + 1}
              </div>
              <p className="text-sm text-slate-600 font-medium leading-relaxed">{point}</p>
            </div>
          ))}
          <div className="pt-8 border-t border-slate-50">
            <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest text-center">
              Last updated: October 2023
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (activeView === 'HELP') {
    return (
      <div className="animate-in slide-in-from-right duration-300 pb-24">
        <BackButton />
        <SubHeader title="Support Hub" icon="fa-solid fa-headset" color="text-[#46D5B3]" />
        
        <div className="space-y-4 mb-10">
          <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Direct Contact</h3>
          
          <div className="grid grid-cols-1 gap-3">
            <a 
              href="tel:+919876543210" 
              className="bg-white p-6 rounded-[2.5rem] border border-slate-50 flex items-center justify-between group active:scale-[0.98] transition-all shadow-sm"
            >
              <div className="flex items-center gap-5">
                <div className="w-12 h-12 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center text-xl">
                  <i className="fa-solid fa-phone"></i>
                </div>
                <div>
                  <p className="text-sm font-black text-slate-800">Call Helpline</p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Instant support 24/7</p>
                </div>
              </div>
              <i className="fa-solid fa-chevron-right text-slate-200 group-hover:text-blue-500 transition-colors"></i>
            </a>

            <a 
              href="https://wa.me/919876543210?text=Hi Neomilez Team, I need help with my journey." 
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white p-6 rounded-[2.5rem] border border-slate-50 flex items-center justify-between group active:scale-[0.98] transition-all shadow-sm"
            >
              <div className="flex items-center gap-5">
                <div className="w-12 h-12 bg-green-50 text-green-500 rounded-2xl flex items-center justify-center text-2xl">
                  <i className="fa-brands fa-whatsapp"></i>
                </div>
                <div>
                  <p className="text-sm font-black text-slate-800">WhatsApp Chat</p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Typical reply: 5 mins</p>
                </div>
              </div>
              <i className="fa-solid fa-chevron-right text-slate-200 group-hover:text-green-500 transition-colors"></i>
            </a>

            <a 
              href="mailto:support@neomilez.com?subject=Support Request" 
              className="bg-white p-6 rounded-[2.5rem] border border-slate-50 flex items-center justify-between group active:scale-[0.98] transition-all shadow-sm"
            >
              <div className="flex items-center gap-5">
                <div className="w-12 h-12 bg-purple-50 text-purple-500 rounded-2xl flex items-center justify-center text-xl">
                  <i className="fa-solid fa-envelope"></i>
                </div>
                <div>
                  <p className="text-sm font-black text-slate-800">Email Support</p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">For detailed inquiries</p>
                </div>
              </div>
              <i className="fa-solid fa-chevron-right text-slate-200 group-hover:text-purple-500 transition-colors"></i>
            </a>
          </div>
        </div>

        {/* Knowledge Base */}
        <div className="space-y-8 mb-10">
          <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest ml-2">Knowledge Base</h3>
          {Object.entries(FAQ_DATA).map(([category, items]) => (
            <div key={category} className="space-y-4">
              <p className="text-[10px] font-black text-[#46D5B3] uppercase tracking-[0.3em] ml-2">{category}</p>
              <div className="space-y-3">
                {items.map(faq => (
                  <div key={faq.id} className="bg-white rounded-[2rem] border border-slate-50 overflow-hidden transition-all shadow-sm">
                    <button 
                      onClick={() => setExpandedFaq(expandedFaq === faq.id ? null : faq.id)}
                      className="w-full p-6 flex items-center justify-between text-left"
                    >
                      <span className="text-[13px] font-black text-slate-700 pr-4">{faq.question}</span>
                      <i className={`fa-solid fa-chevron-down text-[10px] text-slate-300 transition-transform duration-300 ${expandedFaq === faq.id ? 'rotate-180' : ''}`}></i>
                    </button>
                    {expandedFaq === faq.id && (
                      <div className="px-6 pb-6 animate-in slide-in-from-top-2 duration-300">
                        <p className="text-xs text-slate-500 leading-relaxed font-medium bg-slate-50/50 p-4 rounded-2xl border border-slate-50">
                          {faq.answer}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* DEBUG SYNC TEST BUTTON */}
        <div className="pt-10 border-t border-slate-100">
           <p className="text-[8px] font-black text-slate-300 uppercase tracking-[0.2em] text-center mb-4">Developer Tools</p>
           <button 
             onClick={handleForceSyncTest}
             disabled={isTestSyncing}
             className="w-full py-5 bg-[#46D5B3]/10 text-[#46D5B3] rounded-[1.5rem] border border-[#46D5B3]/20 font-black text-[10px] tracking-widest uppercase flex items-center justify-center gap-3 active:scale-95 transition-all"
           >
             <i className={`fa-solid ${isTestSyncing ? 'fa-spinner fa-spin' : 'fa-database'}`}></i>
             {isTestSyncing ? "Syncing Test Packet..." : "Push Random Test Data to Sheets"}
           </button>
        </div>
      </div>
    );
  }

  if (activeView === 'SAFETY') {
    return (
      <div className="animate-in slide-in-from-right duration-300 pb-20">
        <BackButton />
        <SubHeader title="Safety Vault" icon="fa-solid fa-shield-halved" color="text-red-500" />
        
        <div className="bg-red-50 p-8 rounded-[3rem] border border-red-100 mb-8 relative overflow-hidden shadow-xl shadow-red-50">
          <div className="relative z-10">
            <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-red-500 text-2xl mb-6 shadow-sm">
              <i className="fa-solid fa-phone-flip animate-pulse"></i>
            </div>
            <h4 className="text-red-600 font-black text-2xl mb-2 tracking-tight">SOS Emergency</h4>
            <p className="text-red-400 text-[10px] font-bold uppercase tracking-widest mb-8 leading-relaxed">
              Triggers a 5-second countdown to alert authorities and shared emergency contacts.
            </p>
            <button 
              onClick={() => setShowSosConfirm(true)}
              className="w-full py-6 bg-red-500 text-white rounded-[2rem] font-black text-xs tracking-[0.2em] uppercase shadow-2xl shadow-red-200 active:scale-95 transition-all"
            >
              TRIGGER SOS
            </button>
          </div>
          <i className="fa-solid fa-shield-heart absolute -right-8 -bottom-8 text-red-500/5 text-[15rem]"></i>
        </div>

        <div className="space-y-4 mb-8">
          <div className="bg-white p-6 rounded-[2rem] border border-slate-50 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-5">
              <div className="w-12 h-12 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center text-xl">
                <i className="fa-solid fa-location-crosshairs"></i>
              </div>
              <div>
                <p className="text-sm font-black text-slate-800">Live Journey Tracking</p>
                <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">Share your location during trips</p>
              </div>
            </div>
            <button 
              onClick={toggleShareLive}
              className={`w-14 h-8 rounded-full transition-all relative ${shareLive ? 'bg-[#46D5B3]' : 'bg-slate-200'}`}
            >
              <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all shadow-sm ${shareLive ? 'left-7' : 'left-1'}`} />
            </button>
          </div>

          {shareLive && (
            <div className="bg-white/40 backdrop-blur-md p-6 rounded-[2.5rem] border border-[#46D5B3]/20 shadow-lg animate-in slide-in-from-top-4 duration-500">
               <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                     <div className="w-2.5 h-2.5 bg-[#46D5B3] rounded-full animate-ping"></div>
                     <span className="text-[10px] font-black text-[#46D5B3] uppercase tracking-[0.2em]">Live Tracking Active</span>
                  </div>
                  <i className="fa-solid fa-satellite text-slate-300 text-xs"></i>
               </div>
               
               <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                     <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Latitude</p>
                     <p className="text-xs font-black text-slate-700 font-mono">{currentCoords ? currentCoords.lat.toFixed(6) : 'Locating...'}</p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                     <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Longitude</p>
                     <p className="text-xs font-black text-slate-700 font-mono">{currentCoords ? currentCoords.lng.toFixed(6) : 'Locating...'}</p>
                  </div>
               </div>
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center px-2">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Emergency Contacts</h3>
            <button 
              onClick={() => setIsAddingContact(true)}
              className="text-[10px] font-black text-[#46D5B3] uppercase tracking-widest hover:underline"
            >
              + Add New
            </button>
          </div>

          <div className="space-y-3">
            {isAddingContact && (
              <div className="bg-white p-6 rounded-[2.5rem] border border-[#46D5B3] shadow-lg animate-in zoom-in-95 duration-200 space-y-4">
                <div className="space-y-3">
                  <input 
                    type="text" 
                    placeholder="Contact Name"
                    value={newContactName}
                    onChange={(e) => setNewContactName(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 rounded-xl border-none outline-none font-bold text-sm"
                  />
                  <input 
                    type="tel" 
                    placeholder="Phone Number"
                    maxLength={10}
                    value={newContactPhone}
                    onChange={(e) => setNewContactPhone(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-4 py-3 bg-slate-50 rounded-xl border-none outline-none font-bold text-sm"
                  />
                </div>
                <div className="flex gap-3">
                  <button onClick={handleAddContact} className="flex-1 py-3 bg-[#46D5B3] text-white rounded-xl font-black text-[10px] uppercase tracking-widest">Add</button>
                  <button onClick={() => setIsAddingContact(false)} className="flex-1 py-3 bg-slate-100 text-slate-400 rounded-xl font-black text-[10px] uppercase tracking-widest">Cancel</button>
                </div>
              </div>
            )}

            {contacts.map(contact => (
              <div key={contact.id} className="bg-white p-6 rounded-[2.5rem] border border-slate-50 flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-50 text-slate-400 rounded-full flex items-center justify-center font-black">
                    {contact.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-black text-slate-800">{contact.name}</p>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{contact.phone}</p>
                  </div>
                </div>
                {contact.phone !== '112' && (
                  <button 
                    onClick={() => handleRemoveContact(contact.id)}
                    className="w-8 h-8 flex items-center justify-center text-slate-200 hover:text-red-400 transition-colors"
                  >
                    <i className="fa-solid fa-trash-can text-sm"></i>
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (activeView === 'PROFILE') {
    return (
      <div className="animate-in slide-in-from-right duration-300">
        <BackButton />
        <SubHeader title="Edit Profile" icon="fa-solid fa-user-pen" color="text-blue-500" />
        
        <div className="flex flex-col items-center mb-10">
          <div 
            onClick={handleAvatarClick}
            className="group relative w-32 h-32 rounded-[2.5rem] bg-slate-100 border-2 border-dashed border-slate-300 flex items-center justify-center cursor-pointer overflow-hidden transition-all hover:border-[#46D5B3]"
          >
            {editAvatar ? (
              <img src={editAvatar} alt="Profile Preview" className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center gap-2 text-slate-400 group-hover:text-[#46D5B3]">
                <i className="fa-solid fa-camera text-2xl"></i>
                <span className="text-[8px] font-black uppercase tracking-widest">Add Photo</span>
              </div>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleFileChange} 
            />
          </div>
        </div>

        <form onSubmit={handleUpdateProfile} className="space-y-6">
          <div className="bg-white p-6 rounded-[2rem] border border-slate-50 shadow-sm space-y-4">
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-wider">Full Name</label>
              <input 
                type="text" 
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-100 focus:ring-2 focus:ring-[#46D5B3] outline-none font-bold"
              />
            </div>
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-wider">Email Address</label>
              <input 
                type="email" 
                value={editEmail}
                onChange={(e) => setEditEmail(e.target.value)}
                placeholder="email@example.com"
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-100 focus:ring-2 focus:ring-[#46D5B3] outline-none font-bold"
              />
            </div>
          </div>
          <button type="submit" className="w-full py-5 bg-[#46D5B3] text-white rounded-[2rem] font-black shadow-xl shadow-[#46D5B3]/20 active:scale-[0.98] transition-all tracking-widest">
            SAVE CHANGES
          </button>
        </form>
      </div>
    );
  }

  return null;
};

export default MoreScreen;
