
import React from 'react';
import { AppTab } from '../types';

interface BottomNavProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t border-slate-100 px-8 py-3 flex justify-between items-center z-[100] safe-bottom shadow-[0_-10px_30px_rgba(0,0,0,0.05)] rounded-t-[2rem]">
      <button 
        onClick={() => setActiveTab(AppTab.TRIP)}
        className={`flex flex-col items-center gap-1 transition-all duration-300 ${
          activeTab === AppTab.TRIP ? 'text-[#46D5B3]' : 'text-slate-300'
        }`}
      >
        <div className={`text-xl transition-transform ${activeTab === AppTab.TRIP ? 'scale-110' : 'scale-100'}`}>
          <i className="fa-solid fa-map-location-dot"></i>
        </div>
        <span className="text-[9px] font-black uppercase tracking-[0.1em]">Trip</span>
      </button>

      <button 
        onClick={() => setActiveTab(AppTab.MY_RIDES)}
        className={`flex flex-col items-center gap-1 transition-all duration-300 ${
          activeTab === AppTab.MY_RIDES ? 'text-[#46D5B3]' : 'text-slate-300'
        }`}
      >
        <div className={`text-xl transition-transform ${activeTab === AppTab.MY_RIDES ? 'scale-110' : 'scale-100'}`}>
          <i className="fa-solid fa-calendar-check"></i>
        </div>
        <span className="text-[9px] font-black uppercase tracking-[0.1em]">Rides</span>
      </button>

      <button 
        onClick={() => setActiveTab(AppTab.MORE)}
        className={`flex flex-col items-center gap-1 transition-all duration-300 ${
          activeTab === AppTab.MORE ? 'text-[#46D5B3]' : 'text-slate-300'
        }`}
      >
        <div className={`text-xl transition-transform ${activeTab === AppTab.MORE ? 'scale-110' : 'scale-100'}`}>
          <i className="fa-solid fa-bars"></i>
        </div>
        <span className="text-[9px] font-black uppercase tracking-[0.1em]">More</span>
      </button>
    </nav>
  );
};

export default BottomNav;
