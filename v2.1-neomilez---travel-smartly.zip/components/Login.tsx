
import React, { useState } from 'react';
import { User } from '../types';
import { BRAND_NAME } from '../constants';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other' | undefined>();

  const isPhoneValid = phone.length === 10;
  const isFormValid = name.trim().length > 0 && isPhoneValid && gender !== undefined;

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Regex: Remove all non-digit characters
    const cleaned = e.target.value.replace(/\D/g, '');
    // Limit to 10 digits
    if (cleaned.length <= 10) {
      setPhone(cleaned);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isFormValid) {
      onLogin({ name, phone, email, gender });
    }
  };

  const slogan = "TRAVEL SMARTLY";

  return (
    <div className="min-h-screen bg-white flex flex-col px-8 pt-20">
      <div className="flex flex-col items-center mb-12">
        <div className="flex flex-col w-fit">
          <span className="text-5xl font-black text-[#46D5B3] tracking-tighter leading-none mb-1.5">{BRAND_NAME}</span>
          <div className="flex justify-between w-full px-0.5">
            {slogan.split('').map((char, i) => (
              <span key={i} className="text-slate-400 font-black text-[9px] uppercase tracking-normal">
                {char === ' ' ? '\u00A0' : char}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Welcome!</h2>
        <p className="text-slate-500 mb-8 font-medium">Step into the future of eco-friendly shared mobility.</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-wider">Full Name</label>
            <input 
              required
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:ring-2 focus:ring-[#46D5B3] focus:bg-white outline-none transition-all font-semibold text-slate-700"
              placeholder="Your Name"
            />
          </div>

          <div className="relative">
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-wider">Phone Number</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">+91</span>
              <input 
                required
                type="tel" 
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={10}
                value={phone}
                onChange={handlePhoneChange}
                className={`w-full pl-14 pr-12 py-4 rounded-2xl bg-slate-50 border transition-all font-bold text-slate-700 outline-none ${
                  isPhoneValid 
                  ? 'border-[#46D5B3] ring-1 ring-[#46D5B3] bg-white' 
                  : 'border-slate-100 focus:ring-2 focus:ring-slate-200'
                }`}
                placeholder="00000 00000"
              />
              {isPhoneValid && (
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-[#46D5B3] animate-in zoom-in duration-300">
                  <i className="fa-solid fa-circle-check"></i>
                </div>
              )}
            </div>
            <div className="flex justify-between mt-1 px-1">
              <p className="text-[9px] text-slate-300 font-bold uppercase">Numerical digits only</p>
              <p className={`text-[9px] font-bold uppercase transition-colors ${isPhoneValid ? 'text-[#46D5B3]' : 'text-slate-300'}`}>
                {phone.length}/10
              </p>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-wider">Gender</label>
            <div className="grid grid-cols-3 gap-3">
              {(['Male', 'Female', 'Other'] as const).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGender(g)}
                  className={`py-3 rounded-xl border text-sm font-bold transition-all ${
                    gender === g 
                      ? 'bg-[#46D5B3] border-[#46D5B3] text-white shadow-lg shadow-[#46D5B3]/30' 
                      : 'border-slate-100 text-slate-400 bg-slate-50 hover:bg-white'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>
          
          <button 
            type="submit"
            disabled={!isFormValid}
            className={`w-full py-5 rounded-[2rem] font-black text-lg mt-8 transition-all shadow-xl active:scale-[0.98] tracking-widest uppercase ${
              isFormValid 
              ? 'bg-slate-900 text-white shadow-slate-200 hover:bg-slate-800' 
              : 'bg-slate-100 text-slate-300 shadow-none cursor-not-allowed'
            }`}
          >
            LET'S GO
          </button>
        </form>
      </div>

      <footer className="py-8 text-center text-slate-400 text-[10px] font-black tracking-[0.4em] uppercase opacity-50">
        POWERED BY NEOMILEZ ECO-DRIVE
      </footer>
    </div>
  );
};

export default Login;
