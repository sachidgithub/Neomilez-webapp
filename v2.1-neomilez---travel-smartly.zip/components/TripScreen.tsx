
import React, { useState, useMemo } from 'react';
import { BookingType, User, Ride, Route, RouteCategory } from '../types';
import { ROUTES, TIME_SLOTS, RENTAL_PACKAGES, HOURLY_RATE } from '../constants';

interface TripScreenProps {
  user: User;
  onBooking: (ride: Ride) => void;
}

const ROUTE_DETAILS: Record<string, { image: string, distance: string, duration: string }> = {
  '1': { image: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&q=80&w=800', distance: '145 km', duration: '3h 15m' },
  '2': { image: 'https://images.unsplash.com/photo-1590766940554-634a7ed41450?auto=format&fit=crop&q=80&w=800', distance: '145 km', duration: '3h 20m' },
  '3': { image: 'https://images.unsplash.com/photo-1550405992-3293fd96e063?auto=format&fit=crop&q=80&w=800', distance: '35 km', duration: '1h 10m' },
  '4': { image: 'https://images.unsplash.com/photo-1436491865332-7a61a109c0f2?auto=format&fit=crop&q=80&w=800', distance: '35 km', duration: '1h 15m' },
  '5': { image: 'https://images.unsplash.com/photo-1517429128374-99d99702937c?auto=format&fit=crop&q=80&w=800', distance: '40 km', duration: '1h 20m' },
  '6': { image: 'https://images.unsplash.com/photo-1596739050908-417e94589d82?auto=format&fit=crop&q=80&w=800', distance: '40 km', duration: '1h 25m' },
};

const CAR_OPTIONS = [
  { 
    id: 'ev-tigor', 
    name: 'Neo Compact', 
    model: 'Tata Tigor EV', 
    type: 'Sedan', 
    categoryLabel: 'Economic Sedan',
    range: '315km', 
    image: 'https://images.unsplash.com/photo-1620288627223-53302f4e8c74?auto=format&fit=crop&q=80&w=600',
    tag: 'Efficient'
  },
  { 
    id: 'ev-nexon', 
    name: 'Neo SUV', 
    model: 'Tata Nexon EV', 
    type: 'SUV', 
    categoryLabel: 'Economic SUV',
    range: '453km', 
    image: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?auto=format&fit=crop&q=80&w=600',
    tag: 'Versatile'
  },
  { 
    id: 'ev-mgzs', 
    name: 'Neo Luxe', 
    model: 'MG ZS EV', 
    type: 'SUV', 
    categoryLabel: 'Luxury SUV',
    range: '461km', 
    image: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=600',
    tag: 'Premium'
  },
];

interface ConfirmationDetails extends Ride {
  rentalMode?: string;
  carName?: string;
  carImage?: string;
}

const TripScreen: React.FC<TripScreenProps> = ({ user, onBooking }) => {
  const [bookingType, setBookingType] = useState<BookingType>(BookingType.INTERCITY);
  const [step, setStep] = useState(1);
  const [rentalMode, setRentalMode] = useState<'SELF' | 'DRIVER'>('SELF');
  const [selectedCategory, setSelectedCategory] = useState<RouteCategory | null>(null);
  const [selectedRoute, setSelectedRoute] = useState<Route | null>(null);
  const [selectedCar, setSelectedCar] = useState(CAR_OPTIONS[0]);
  const [selectedTime, setSelectedTime] = useState(TIME_SLOTS[0]);
  const [seats, setSeats] = useState(1);
  const [rentalHours, setRentalHours] = useState(4);
  const [pendingRide, setPendingRide] = useState<ConfirmationDetails | null>(null);
  const [showConfirmation, setShowConfirmation] = useState<ConfirmationDetails | null>(null);

  const driverFee = 500;
  const totalPrice = useMemo(() => {
    const base = rentalHours * HOURLY_RATE;
    return rentalMode === 'DRIVER' ? base + driverFee : base;
  }, [rentalHours, rentalMode]);

  const handleRouteSelect = (route: Route) => {
    setSelectedRoute(route);
    setStep(2);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const prepareIntercityReview = () => {
    if (!selectedRoute) return;
    setPendingRide({
      id: Math.random().toString(36).substr(2, 9).toUpperCase(),
      type: BookingType.INTERCITY,
      from: selectedRoute.from,
      to: selectedRoute.to,
      date: new Date().toLocaleDateString('en-CA'),
      time: selectedTime,
      status: 'Upcoming',
      price: selectedRoute.pricePerSeat * seats,
      seats: seats,
      carName: selectedCar.model,
      carImage: selectedCar.image
    });
  };

  const prepareRentalReview = () => {
    setPendingRide({
      id: Math.random().toString(36).substr(2, 9).toUpperCase(),
      type: BookingType.PRIVATE_RENTAL,
      from: 'Current Location',
      to: 'Private Rental',
      date: new Date().toLocaleDateString('en-CA'),
      time: 'Scheduled',
      status: 'Upcoming',
      price: totalPrice,
      duration: rentalHours,
      rentalMode: rentalMode === 'SELF' ? 'Self-Drive' : 'With Chauffeur',
      carName: selectedCar.model,
      carImage: selectedCar.image
    });
  };

  const finalizeBooking = () => {
    if (pendingRide) {
      onBooking(pendingRide);
      setShowConfirmation(pendingRide);
      setPendingRide(null);
    }
  };

  const ReviewScreen = ({ ride }: { ride: ConfirmationDetails }) => (
    <div className="fixed inset-0 z-[120] flex flex-col bg-slate-50 animate-in slide-in-from-bottom duration-500 overflow-y-auto pb-40">
      <div className="px-6 py-6 flex items-center gap-4">
        <button onClick={() => setPendingRide(null)} className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-slate-400">
          <i className="fa-solid fa-arrow-left"></i>
        </button>
        <h2 className="text-xl font-black text-slate-800 tracking-tight">Review Booking</h2>
      </div>

      <div className="px-6 space-y-6">
        {/* Ticket UI */}
        <div className="bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-100 overflow-hidden relative">
          <div className="p-8">
             <div className="flex justify-between items-start mb-8">
               <div>
                 <p className="text-[10px] font-black text-[#46D5B3] uppercase tracking-[0.2em] mb-1">Neo Ticket</p>
                 <h3 className="text-2xl font-black text-slate-900">
                    {ride.type === BookingType.INTERCITY ? 'Shared Ride' : 'Private Rental'}
                 </h3>
               </div>
               <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 border border-slate-100">
                  <i className="fa-solid fa-qrcode text-3xl"></i>
               </div>
             </div>

             <div className="space-y-6">
               <div className="flex items-start gap-4">
                  <div className="flex flex-col items-center pt-1.5">
                    <div className="w-2.5 h-2.5 rounded-full border-2 border-[#46D5B3] bg-white"></div>
                    <div className="w-0.5 h-8 bg-slate-50"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-[#46D5B3]"></div>
                  </div>
                  <div className="flex-1 space-y-6">
                    <div>
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Pickup</p>
                      <p className="text-sm font-black text-slate-800">{ride.from}</p>
                    </div>
                    <div>
                      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Drop-off</p>
                      <p className="text-sm font-black text-slate-800">{ride.to}</p>
                    </div>
                  </div>
               </div>

               <div className="grid grid-cols-2 gap-6 pt-4">
                  <div>
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Schedule</p>
                    <p className="text-xs font-black text-slate-800">{ride.date}</p>
                    <p className="text-[10px] font-bold text-slate-500">{ride.time}</p>
                  </div>
                  <div>
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Capacity</p>
                    <p className="text-xs font-black text-slate-800">
                      {ride.type === BookingType.INTERCITY ? `${ride.seats} Passenger(s)` : `${ride.duration}h • ${ride.rentalMode}`}
                    </p>
                  </div>
               </div>
             </div>
          </div>

          <div className="h-px bg-slate-50 relative">
             <div className="absolute -left-3 -top-3 w-6 h-6 bg-slate-50 rounded-full border border-slate-100"></div>
             <div className="absolute -right-3 -top-3 w-6 h-6 bg-slate-50 rounded-full border border-slate-100"></div>
          </div>

          <div className="p-8 bg-slate-50/50">
             <div className="flex items-center gap-4">
                <div className="w-16 h-12 rounded-xl overflow-hidden bg-white border border-slate-100 flex-shrink-0">
                  <img src={ride.carImage} className="w-full h-full object-cover" alt={ride.carName} />
                </div>
                <div>
                   <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-0.5">EV Class</p>
                   <p className="text-xs font-black text-slate-800">{ride.carName}</p>
                </div>
             </div>
          </div>
        </div>

        <div className="space-y-4 pt-4">
          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Fare Breakdown</h4>
          <div className="bg-white p-6 rounded-3xl border border-slate-100 space-y-3">
             <div className="flex justify-between items-center text-sm font-bold text-slate-600">
                <span>Base Fare</span>
                <span>₹{ride.price}</span>
             </div>
             <div className="flex justify-between items-center text-sm font-bold text-slate-600">
                <span>Neo Support Fee</span>
                <span className="text-[#46D5B3]">FREE</span>
             </div>
             <div className="pt-3 border-t border-slate-50 flex justify-between items-center">
                <span className="text-sm font-black text-slate-800">Total Payable</span>
                <span className="text-2xl font-black text-slate-900">₹{ride.price}</span>
             </div>
          </div>
        </div>

        <div className="bg-blue-50/50 p-6 rounded-3xl border border-blue-100 flex gap-4">
           <i className="fa-solid fa-circle-info text-blue-400 mt-1"></i>
           <p className="text-[10px] text-blue-500 font-bold leading-relaxed uppercase tracking-widest">
             By clicking confirm, you agree to our Travel Policy. Cancellation is free up to 4 hours before departure.
           </p>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white border-t border-slate-50 flex items-center gap-4">
         <button 
           onClick={() => setPendingRide(null)}
           className="flex-1 py-5 bg-slate-50 text-slate-400 rounded-2xl font-black text-xs tracking-widest uppercase active:scale-95 transition-all"
         >
           Cancel
         </button>
         <button 
           onClick={finalizeBooking}
           className="flex-[2] py-5 bg-slate-900 text-[#46D5B3] rounded-2xl font-black text-xs tracking-[0.2em] uppercase shadow-xl active:scale-95 transition-all animate-pulse"
         >
           Confirm & Pay
         </button>
      </div>
    </div>
  );

  const SuccessModal = ({ ride }: { ride: ConfirmationDetails }) => (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-white w-full max-sm rounded-[3rem] p-10 shadow-2xl animate-in zoom-in-95 duration-300 flex flex-col items-center text-center">
        <div className="w-20 h-20 bg-[#46D5B3]/10 text-[#46D5B3] rounded-full flex items-center justify-center text-4xl mb-6">
          <i className="fa-solid fa-check"></i>
        </div>
        <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tight">Booking Secured</h3>
        <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] mb-8 leading-relaxed">
          Your Neo Journey with ID NEO-{ride.id} is confirmed. Details sent via WhatsApp.
        </p>
        <button 
          onClick={() => setShowConfirmation(null)}
          className="w-full py-5 bg-slate-900 text-white rounded-[2rem] font-black text-xs tracking-[0.3em] uppercase shadow-2xl active:scale-95 transition-all"
        >
          VIEW MY RIDES
        </button>
      </div>
    </div>
  );

  // Fix: Changed comparison to check if current booking type is PRIVATE_RENTAL
  if (bookingType === BookingType.PRIVATE_RENTAL) {
    return (
      <div className="space-y-8 pb-40 animate-in fade-in slide-in-from-bottom-2 duration-500">
        {pendingRide && <ReviewScreen ride={pendingRide} />}
        {showConfirmation && <SuccessModal ride={showConfirmation} />}
        
        <div className="flex items-center justify-between px-1">
          <button 
             onClick={() => { setBookingType(BookingType.INTERCITY); setStep(1); setSelectedCategory(null); }}
             className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2 hover:text-slate-900 transition-colors"
           >
             <i className="fa-solid fa-arrow-left"></i> Shared Trips
           </button>
           <span className="text-[10px] font-black text-[#46D5B3] uppercase tracking-widest">Premium Fleet</span>
        </div>

        <div className="bg-slate-100 p-1 rounded-2xl flex relative">
          <button 
            onClick={() => setRentalMode('SELF')}
            className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.1em] transition-all z-10 ${
              rentalMode === 'SELF' ? 'text-slate-900' : 'text-slate-400'
            }`}
          >
            Self-Drive
          </button>
          <button 
            onClick={() => setRentalMode('DRIVER')}
            className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.1em] transition-all z-10 ${
              rentalMode === 'DRIVER' ? 'text-slate-900' : 'text-slate-400'
            }`}
          >
            With Chauffeur
          </button>
          <div 
            className={`absolute top-1 bottom-1 w-[calc(50%-4px)] bg-white rounded-xl shadow-sm transition-transform duration-300 ease-out ${
              rentalMode === 'DRIVER' ? 'translate-x-[calc(100%+0px)]' : 'translate-x-0'
            }`}
          />
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">Select EV</h3>
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Swipe for more</span>
          </div>
          <div className="flex overflow-x-auto gap-4 pb-2 no-scrollbar snap-x snap-mandatory">
            {CAR_OPTIONS.map(car => (
              <div 
                key={car.id}
                onClick={() => setSelectedCar(car)}
                className={`snap-center min-w-[200px] bg-white rounded-3xl border-2 transition-all cursor-pointer relative overflow-hidden group ${
                  selectedCar.id === car.id ? 'border-[#46D5B3] shadow-lg scale-100' : 'border-slate-50 opacity-60'
                }`}
              >
                <div className="p-5">
                   <div className="flex justify-between items-start mb-4">
                     <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${selectedCar.id === car.id ? 'bg-[#46D5B3] text-white' : 'bg-slate-100 text-slate-400'}`}>
                       {car.type}
                     </span>
                     <i className={`fa-solid fa-leaf text-xs ${selectedCar.id === car.id ? 'text-[#46D5B3]' : 'text-slate-200'}`}></i>
                   </div>
                   <div className="h-24 flex items-center justify-center mb-4">
                     <img src={car.image} className="h-full w-full object-cover rounded-2xl" alt={car.name} />
                   </div>
                   <div className="text-center">
                     <h4 className="font-black text-slate-900 text-sm leading-tight">{car.model}</h4>
                     <p className="text-[9px] font-bold text-slate-400 uppercase mt-1.5">{car.range} Range • {car.tag}</p>
                   </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest px-1">Duration</h3>
          <div className="flex flex-wrap gap-3">
            {RENTAL_PACKAGES.map(h => (
              <button 
                key={h} 
                onClick={() => setRentalHours(h)} 
                className={`flex-1 min-w-[70px] py-4 rounded-2xl border-2 font-black transition-all ${
                  rentalHours === h 
                  ? 'border-[#46D5B3] bg-[#46D5B3]/5 text-[#46D5B3]' 
                  : 'border-slate-50 bg-white text-slate-300'
                }`}
              >
                <span className="text-lg">{h}</span>
                <span className="text-[10px] ml-1 uppercase">H</span>
              </button>
            ))}
          </div>
        </div>

        <div className="fixed bottom-[90px] left-0 right-0 px-6 z-[110]">
          <div className="bg-slate-900 p-6 rounded-[2.5rem] shadow-2xl flex items-center justify-between border border-white/5 backdrop-blur-xl">
            <div className="flex flex-col">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                {rentalHours}h • {rentalMode === 'SELF' ? 'Self' : 'Chauffeur'}
              </p>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-black text-white">₹{totalPrice}</span>
              </div>
            </div>
            <button 
              onClick={prepareRentalReview}
              className="bg-[#46D5B3] text-slate-900 px-8 py-4 rounded-2xl font-black shadow-xl active:scale-95 transition-all text-[11px] tracking-widest uppercase"
            >
              Continue
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {pendingRide && <ReviewScreen ride={pendingRide} />}
      {showConfirmation && <SuccessModal ride={showConfirmation} />}
      
      <div className="bg-slate-200/50 p-1.5 rounded-[1.5rem] flex mb-4 backdrop-blur-sm">
        <button 
          onClick={() => setBookingType(BookingType.INTERCITY)}
          className={`flex-1 py-3 rounded-[1.2rem] text-sm font-black transition-all ${
            bookingType === BookingType.INTERCITY ? 'bg-white text-slate-900 shadow-xl' : 'text-slate-400'
          }`}
        >
          Fixed Routes
        </button>
        <button 
          onClick={() => setBookingType(BookingType.PRIVATE_RENTAL)} 
          className={`flex-1 py-3 rounded-[1.2rem] text-sm font-black transition-all ${
            bookingType === BookingType.PRIVATE_RENTAL ? 'bg-white text-slate-900 shadow-xl' : 'text-slate-400'
          }`}
        >
          Private Rental
        </button>
      </div>

      {step === 1 ? (
        <div className="space-y-6 pb-24">
          {!selectedCategory ? (
            <>
              <div>
                <p className="text-[10px] font-black text-[#46D5B3] uppercase tracking-[0.3em] mb-1">Select Service</p>
                <h2 className="text-3xl font-black text-slate-800 tracking-tight">Eco-Friendly Shared Mobility</h2>
              </div>
              <div className="grid grid-cols-1 gap-4">
                <button 
                  onClick={() => setSelectedCategory(RouteCategory.INTERCITY)}
                  className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-50 flex items-center justify-between group active:scale-[0.98] transition-all"
                >
                  <div className="flex items-center gap-8 text-left">
                    <div className="w-16 h-16 bg-[#46D5B3]/10 rounded-3xl flex items-center justify-center text-3xl text-[#46D5B3] group-hover:bg-[#46D5B3] group-hover:text-white transition-all shadow-inner">
                      <i className="fa-solid fa-road"></i>
                    </div>
                    <div>
                      <h3 className="text-2xl font-black text-slate-800">Intercity</h3>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Shared fixed schedules</p>
                    </div>
                  </div>
                  <i className="fa-solid fa-chevron-right text-slate-200 group-hover:text-[#46D5B3] group-hover:translate-x-1 transition-all"></i>
                </button>

                <button 
                  onClick={() => setSelectedCategory(RouteCategory.AIRPORT)}
                  className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-50 flex items-center justify-between group active:scale-[0.98] transition-all"
                >
                  <div className="flex items-center gap-8 text-left">
                    <div className="w-16 h-16 bg-blue-500/10 rounded-3xl flex items-center justify-center text-3xl text-blue-500 group-hover:bg-blue-500 group-hover:text-white transition-all shadow-inner">
                      <i className="fa-solid fa-plane-departure"></i>
                    </div>
                    <div>
                      <h3 className="text-2xl font-black text-slate-800">Airport</h3>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Direct airport shuttles</p>
                    </div>
                  </div>
                  <i className="fa-solid fa-chevron-right text-slate-200 group-hover:text-blue-500 group-hover:translate-x-1 transition-all"></i>
                </button>
              </div>
            </>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <div>
                  <button onClick={() => setSelectedCategory(null)} className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 flex items-center gap-1 group">
                    <i className="fa-solid fa-chevron-left group-hover:-translate-x-1 transition-transform"></i> Services
                  </button>
                  <h2 className="text-3xl font-black text-slate-800 tracking-tight">
                    {selectedCategory === RouteCategory.INTERCITY ? 'Intercity' : 'Airport'} Routes
                  </h2>
                </div>
              </div>
              <div className="space-y-6">
                {ROUTES.filter(r => r.category === selectedCategory).map(route => {
                  const details = ROUTE_DETAILS[route.id];
                  return (
                    <div 
                      key={route.id}
                      onClick={() => handleRouteSelect(route)}
                      className="bg-white rounded-[2.5rem] overflow-hidden shadow-sm border border-slate-50 active:scale-[0.98] transition-all cursor-pointer group"
                    >
                      <div className="relative h-48">
                        <img src={details.image} alt={route.to} className="w-full h-full object-cover grayscale-[0.3] group-hover:grayscale-0 transition-all duration-500" />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent"></div>
                        <div className="absolute bottom-6 right-6 bg-[#46D5B3] text-slate-900 px-5 py-2 rounded-2xl shadow-2xl">
                          <p className="text-xl font-black">₹{route.pricePerSeat}</p>
                        </div>
                      </div>
                      <div className="p-8">
                        <div className="flex justify-between items-center mb-4">
                           <h3 className="text-2xl font-black text-slate-800 tracking-tight">{route.from} → {route.to}</h3>
                        </div>
                        <div className="flex gap-6">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                            <i className="fa-solid fa-road text-[#46D5B3]"></i> {details.distance}
                          </span>
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                            <i className="fa-solid fa-clock text-[#46D5B3]"></i> {details.duration}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      ) : (
        <div className="space-y-8 pb-64 animate-in slide-in-from-right duration-400">
          <div className="flex items-center justify-between px-2">
            <button onClick={() => setStep(1)} className="flex items-center gap-2 text-slate-400 font-black text-[10px] uppercase tracking-widest group">
              <i className="fa-solid fa-chevron-left text-[#46D5B3] group-hover:-translate-x-1 transition-transform"></i> Change Route
            </button>
            <div className="px-4 py-1.5 bg-[#46D5B3]/10 rounded-full border border-[#46D5B3]/20">
              <span className="text-[10px] font-black text-[#46D5B3] uppercase tracking-widest">Active Select</span>
            </div>
          </div>
          
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 text-center">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mb-3">Your Journey</p>
            <h3 className="text-2xl font-black text-slate-900">{selectedRoute?.from} <i className="fa-solid fa-arrow-right-long mx-2 text-[#46D5B3]"></i> {selectedRoute?.to}</h3>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center px-1">
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-2">Vehicle Preference</h3>
            </div>
            <div className="flex overflow-x-auto gap-4 pb-4 no-scrollbar snap-x snap-mandatory">
              {CAR_OPTIONS.map(car => (
                <div 
                  key={car.id}
                  onClick={() => setSelectedCar(car)}
                  className={`snap-center min-w-[240px] bg-white rounded-3xl border-2 transition-all cursor-pointer relative overflow-hidden group ${
                    selectedCar.id === car.id ? 'border-[#46D5B3] shadow-lg scale-100' : 'border-slate-50 opacity-60'
                  }`}
                >
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${selectedCar.id === car.id ? 'bg-[#46D5B3] text-white' : 'bg-slate-100 text-slate-400'}`}>
                        {car.categoryLabel}
                      </span>
                    </div>
                    <div className="h-28 flex items-center justify-center mb-4">
                      <img src={car.image} className="h-full w-full object-cover rounded-2xl" alt={car.name} />
                    </div>
                    <div className="text-center">
                      <h4 className="font-black text-slate-900 text-sm leading-tight">{car.model}</h4>
                      <p className="text-[9px] font-bold text-slate-400 uppercase mt-1.5">{car.range} Range • {car.tag}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-2">Passenger Count</h3>
            <div className="grid grid-cols-3 gap-4">
              {[1, 2, 3].map(n => (
                <button
                  key={n}
                  onClick={() => setSeats(n)}
                  className={`py-6 rounded-[2rem] border-2 font-black text-xl transition-all ${
                    seats === n ? 'bg-slate-900 text-white border-slate-900 shadow-xl' : 'bg-white border-slate-50 text-slate-300'
                  }`}
                >
                  {n}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4 pb-20">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-2">Departure Window</h3>
            <div className="grid grid-cols-3 gap-2">
              {TIME_SLOTS.map(slot => (
                <button
                  key={slot}
                  onClick={() => setSelectedTime(slot)}
                  className={`py-4 rounded-xl border text-[9px] font-black transition-all uppercase tracking-widest ${
                    selectedTime === slot ? 'bg-[#46D5B3] border-[#46D5B3] text-white shadow-lg shadow-[#46D5B3]/20' : 'bg-white border-slate-50 text-slate-500'
                  }`}
                >
                  {slot}
                </button>
              ))}
            </div>
          </div>

          <div className="fixed bottom-[90px] left-0 right-0 px-6 z-[110]">
            <div className="bg-slate-900 p-6 rounded-[3rem] shadow-2xl flex items-center justify-between border border-white/5 backdrop-blur-xl">
              <div className="flex flex-col">
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.3em] mb-1">Total Due</p>
                <p className="text-3xl font-black text-white leading-none">₹{(selectedRoute?.pricePerSeat || 0) * seats}</p>
              </div>
              <button 
                onClick={prepareIntercityReview}
                className="bg-[#46D5B3] text-slate-900 px-10 py-5 rounded-[1.5rem] font-black shadow-2xl shadow-[#46D5B3]/20 active:scale-95 transition-all text-sm tracking-widest uppercase"
              >
                Review
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TripScreen;
